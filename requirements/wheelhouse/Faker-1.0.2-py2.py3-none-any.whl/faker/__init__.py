from faker.generator import Generator  # noqa F401
from faker.factory import Factory  # noqa F401

VERSION = '1.0.2'

Faker = Factory.create
