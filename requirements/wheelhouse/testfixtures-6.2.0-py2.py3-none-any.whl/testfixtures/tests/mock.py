from __future__ import absolute_import

try:
    from unittest.mock import Mock, call, patch, MagicMock, DEFAULT
except:
    from mock import Mock, call, patch, MagicMock, DEFAULT
