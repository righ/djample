(function () {
    djdt.applyStyle('padding-left');
})();
